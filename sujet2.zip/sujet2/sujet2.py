import os
if os.path.exists("notes.txt"): #on verifie si le fichier notes.txt existe dans le repertoire
    print("le fichier existe.")#si le fichier existe on affiche ce message 
else:
    print("le fichier n'existe pas.")#sinon on affiche celui ci 

f = open("notes.txt", "r") # on ouvre le fichier notes.txt en mode lecture "r"
s = 0 #variable pour stocker la somme des notes
c = 0 #variable pour compter le nombre de note
note = [] #liste vide pour stocker toutes les notes deja lues du fichier
moyenne = 0 #variable moyenne initialisé a zero pour contenir la moyenne calculer plustard
print("les notes sont :") #on annonce l'affichage des notes
for line in f : #on parcour le fichier ligne par ligne 
    v = line.strip() #on enleve les espaces de fin de ligne 
    if v == 'notes' : continue #si la premiere ligne contient  le mot "notes", on passe a la ligne suivante
    s += int(v) #on converti la valeur en entier et on l'ajoute à la somme
    c += 1 #on incremente le compteur de notes
    note.append(int(v)) #on ajoute la note dans la liste
    print(v) #on affiche les notes lue
def compute_stats(note): #on analyse les données numeriques 
    if  note :
        moyenne = sum(note)/len(note) #on calcul la moyenne
    return {"moyenne": moyenne} #on renvoi la moyenne dans un dictionnaire
stats = compute_stats(note) #on appelle la fonction compute_stats pour calculer les statistiques 
note_max = max(note) #calcul du maximum
note_min = min(note) #calcul du minimum
print("la moyenne est : ", stats["moyenne"]) #on affiche la moyenne
print("la note maximale est : ", note_max) #on affiche la note maximale
print("la note minimal est : ", note_min) #on affiche la note minimale

f.close() #on ferme le ficher
